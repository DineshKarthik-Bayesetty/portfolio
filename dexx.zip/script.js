document.addEventListener('DOMContentLoaded', () => {
  const sections = document.querySelectorAll('.section');
  const glassPanels = document.querySelectorAll('.glass-panel');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.2 });

  sections.forEach(section => observer.observe(section));
  glassPanels.forEach(panel => observer.observe(panel));
});

document.getElementById('contact-form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert("Thank you! Your message has been sent.");
  this.reset();
});
